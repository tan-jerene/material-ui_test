### Problem description

### Steps to reproduce

### Versions

- Material-UI: 
- React: 
- Browser: 

<!-- Have a QUESTION? Please ask in [StackOverflow or gitter](http://tr.im/77pVj before opening an issue.

If you are having an issue with click events, please re-read the [README](http://tr.im/410Fg) (you did read the README, right? :-) ).

If you think you have found a _new_ issue that hasn't already been reported or fixed in HEAD, please complete the template above.

For feature requests, please delete the template above and use this one instead:

### Description
### Images & references

-->
