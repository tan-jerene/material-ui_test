# eslint-plugin-material-ui

Custom eslint rules for Material-UI

## Supported Rules

* docgen-ignore-before-comment
