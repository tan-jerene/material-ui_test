Radio
=====



Props
-----


| Name | Type | Default | Description |
|:-----|:-----|:-----|:-----|
| checkedClassName | string |  |   |
| className | string |  |   |
| label | string |  |   |
| name | string |  |   |
| onChange | function |  |   |
| value | string |  |   |
