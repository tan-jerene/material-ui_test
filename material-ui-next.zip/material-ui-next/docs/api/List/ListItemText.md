ListItemText
============



Props
-----


| Name | Type | Default | Description |
|:-----|:-----|:-----|:-----|
| className | string |  |   |
| primary | node |  |   |
| secondary | node |  |   |
