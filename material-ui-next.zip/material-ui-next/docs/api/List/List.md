List
====

A simple list component.

Props
-----


| Name | Type | Default | Description |
|:-----|:-----|:-----|:-----|
| children | node |  |   |
| className | string |  |   |
| component | union | 'div' |   |
| padding | bool | true |   |
