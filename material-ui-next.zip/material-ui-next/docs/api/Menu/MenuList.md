MenuList
========



Props
-----


| Name | Type | Default | Description |
|:-----|:-----|:-----|:-----|
| children | node |  |  MenuList contents, should be menu items |
| className | string |  |  The CSS class name of the list element. |
