AppBar
======



Props
-----


| Name | Type | Default | Description |
|:-----|:-----|:-----|:-----|
| accent | bool |  |   |
| children | node |  |   |
| className | string |  |   |
| primary | bool | true |   |
