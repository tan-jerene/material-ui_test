Switch
======



Props
-----


| Name | Type | Default | Description |
|:-----|:-----|:-----|:-----|
| checkedClassName | string |  |   |
| className | string |  |   |
