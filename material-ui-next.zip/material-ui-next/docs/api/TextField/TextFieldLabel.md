TextFieldLabel
==============



Props
-----


| Name | Type | Default | Description |
|:-----|:-----|:-----|:-----|
| animated | bool | true |   |
| className | string |  |   |
| shrink | bool |  |   |
