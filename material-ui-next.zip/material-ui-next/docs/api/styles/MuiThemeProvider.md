MuiThemeProvider
================



Props
-----


| Name | Type | Default | Description |
|:-----|:-----|:-----|:-----|
| <span style="color: #31a148">children *</span> | node |  |   |
| styleManager | object |  |   |
| theme | object |  |   |
