Text
====



Props
-----


| Name | Type | Default | Description |
|:-----|:-----|:-----|:-----|
| align | string |  |   |
| children | node |  |   |
| className | string |  |   |
| component | string | 'span' |   |
| noWrap | bool |  |   |
| type | string | 'body1' |   |
