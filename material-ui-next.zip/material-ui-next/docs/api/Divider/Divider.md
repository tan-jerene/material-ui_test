Divider
=======



Props
-----


| Name | Type | Default | Description |
|:-----|:-----|:-----|:-----|
| absolute | bool |  |   |
| className | string |  |   |
| light | bool |  |   |
