TouchRipple
===========



Props
-----


| Name | Type | Default | Description |
|:-----|:-----|:-----|:-----|
| center | bool |  |   |
| className | string |  |   |
