Ripple
======



Props
-----


| Name | Type | Default | Description |
|:-----|:-----|:-----|:-----|
| className | string |  |   |
| pulsate | bool | false |   |
| rippleSize | number |  |   |
| rippleX | number |  |   |
| rippleY | number |  |   |
