// @flow weak

import React from 'react';
import Button from 'material-ui/Button';

export default function FlatButton() {
  return <Button>Hello World</Button>;
}
