// @flow weak

import React from 'react';
import Button from 'material-ui/Button';

export default function RaisedButton() {
  return <Button raised primary>Hello World</Button>;
}
