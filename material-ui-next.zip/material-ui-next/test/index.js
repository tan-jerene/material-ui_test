// @flow weak
require('babel-register');
require('app-module-path').addPath(`${__dirname}'./../`);
require('./cli');
